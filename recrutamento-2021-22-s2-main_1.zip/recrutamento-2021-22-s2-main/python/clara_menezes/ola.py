import random
def ola(nome):
  options=["Hello,", "Welcome,", "Hi"]
  print(random.choice(options), nome)
  return;

def adeus(nome):
  print("Bye", nome)
  return;
