# Projetos de Recrutamento: 2º Semestre do Ano Letivo 2021/2022

Olá recrutas!

A entrega dos vossos projetos será feita através deste repositório.
Cada um dos projetos tem uma pasta própria e devem enviar um pull request de uma pasta com nome "primeironome_últimonome" para a pasta correspondente a cada projeto.

Qualquer dúvida quanto às entregas, falem com os Recursos Humanos (Ana Martins#8726 no Discord)!
