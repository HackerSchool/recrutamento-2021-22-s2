import random
#Função para registar o utilizador
def registar():
    db = open("registo.txt", "r")
    username = input("Registe o username: ")
    password = input("Registe a password: ")
    confirmarPassword = input("Confirme a password: ")
    d = []
    f = []
    for i in db:
        a, b = i.split(", ")
        b = b.split()
        db.append(a)
        f.append(b)
    if password != confirmarPassword:
        print("Passwords nao combinam. Por favor tente novamente")
    else:
        if len(password) < 6:
            print("Password demasiado curta. Tem de ter no minimo 6 caracteres. Por favor tente novamente:")
            registar()
        else:
            if username in d:
                print("Username já existente. Por favor tente novamente:")
                registar()
            else:
                db = open("database.txt", "a")
                db.write(username + ", " + password + "\n")
                print("Parabens! Acabas-te de criar uma conta.")
                menu()
#Função para entrar na app
def acesso(username=None, password=None):
  db = open("database.txt", "r")
  username = input("Enter your username:")
  password = input("Enter your Password:")  
  if not len(username or password) < 1:
    d = []
    f = []
    for i in db:
      a,b = i.split(",")
      b = b.strip()
      d.append(a)
      f.append(b)
    data = dict(zip(d, f))
    
    if data[username]:
        
      if password == data[username]:
            print("Bem-Vind@,", username,"!!\nNesta app terás 3 opções!!")
            app()
      else:
            print("Password ou username incorretos")
         
    else:
        print("Username não existem")

  else:
    print("Introduza o username ou a password")
    acesso()    
#Função para escolher a app
def app(opcoes1=None):
  opcoes1 = input("Insera o número da opção que deseja:\n1.Calculadora\n2.TicTacToe\n")
  if opcoes1 == "1":
    calculadora()
  elif opcoes1 == "2":
    TicTacToe()
  else:
    print ("Inválido. Tente novamente")
    app()
#Função para a app - calculadora
def calculadora(operacao=None):
  while (sair != "S" or sair != "s"):
    print ("Deseja sair? [S - N]")
    sair = input()
    if sair != "S" or sair != "s":
      print("Seleciona a operação que deseja\n1. Adição\n2. Subtração\n3. Multiplicação\n4. Divisão\n5. Exponencial\n6. Resto da divisão")
    operacao = input()
#Operação de adição
    if operacao == "1":
        n1 = int(input("Intruduza o primeiro número:"))
        n2 = int(input("Intruduza o segundo número:"))
        adicao = n1 + n2
        print("Resultado:", adicao)
#Operação de subtração
    elif operacao == "2":
        n1 = int(input("Intruduza o primeiro número:"))
        n2 = int(input("Intruduza o segundo número:"))
        subtracao = n1 - n2
        print("Resultado:", subtracao)
#Operação de multiplicação
    elif operacao == "3":
        n1 = int(input("Intruduza o primeiro número:"))
        n2 = int(input("Intruduza o segundo número:"))
        multiplicacao = n1 * n2
        print("Resultado:", multiplicacao)
#Operação de divisão
    elif operacao == "4":
        n1 = int(input("Intruduza o primeiro número:"))
        n2 = int(input("Intruduza o segundo número:"))
        divisao = n1 / n2
        print("Resultado:", divisao)
#Operação Exponencial
    elif operacao == "5":
        n1 = int(input("Intruduza o número de base:"))
        n2 = int(input("Intruduza o número de expoente:"))
        exp = n1 ** n2
        print("Resultado:", exp)
    elif operacao == "6":
        n1 = int(input("Intruduza o primeiro número:"))
        n2 = int(input("Intruduza o segundo número:"))
        resto = n1 % n2
        print("Resultado:", resto)
    else:
        print("Inválido")
  else:
    exit()
#TicTacToe
def TicTacToe():
  while (sair != "S" or sair != "s"):
    print ("Deseja sair? [S - N]")
    sair = input()
    if sair != "S" or sair != "s":
      tabuleiro = ["1", "2", "3",
                   "4", "5", "6",
                   "7", "8", "9"]
      jogador = "X"
      vencedor = None
      jogo = True
# tabuleiro
      def Tabuleiro(tabuleiro):
          print(tabuleiro[0] + " | " + tabuleiro[1] + " | " + tabuleiro[2])
          print("--+---+--")
          print(tabuleiro[3] + " | " + tabuleiro[4] + " | " + tabuleiro[5])
          print("--+---+--")
          print(tabuleiro[6] + " | " + tabuleiro[7] + " | " + tabuleiro[8])
#Jogador joga
      def Pjogador(tabuleiro):
          inp = int(input("Seleciona a casa que deseja "))
          if tabuleiro[inp-1] == "1" or tabuleiro[inp-1] == "2" or tabuleiro[inp-1] == "3" or tabuleiro[inp-1] == "4" or tabuleiro[inp-1] == "5" or tabuleiro[inp-1] == "6" or tabuleiro[inp-1] == "7" or tabuleiro[inp-1] == "8" or tabuleiro[inp-1] == "9":
              tabuleiro[inp-1] = jogador
          else:
              print("Esse lugar já está ocupado!")
#vitória ou empate - horizontal
      def Horizontal(tabuleiro):
          global vencedor
          if tabuleiro[0] == tabuleiro[1] == tabuleiro[2] and (tabuleiro[0] != "1" or tabuleiro[0] != "2" or tabuleiro[0] != "3"):
              vencedor = tabuleiro[0]
              return True
          elif tabuleiro[3] == tabuleiro[4] == tabuleiro[5] and (tabuleiro[3] != "4" or tabuleiro[3] != "5" or tabuleiro[3] != "6"):
              vencedor = tabuleiro[3]
              return True
          elif tabuleiro[6] == tabuleiro[7] == tabuleiro[8] and (tabuleiro[6] != "7" or tabuleiro[6] != "8" or tabuleiro[6] != "9"):
              vencedor = tabuleiro[6]
              return True
#vitória ou empate - vertical
      def Vertical(tabuleiro):
          global vencedor
          if tabuleiro[0] == tabuleiro[3] == tabuleiro[6] and (tabuleiro[0] != "1" or tabuleiro[0] != "4" or tabuleiro[0] != "7"):
              vencedor = tabuleiro[0]
              return True
          elif tabuleiro[1] == tabuleiro[4] == tabuleiro[7] and (tabuleiro[1] != "2" or tabuleiro[1] != "5" or tabuleiro[1] != "8"):
              vencedor = tabuleiro[1]
              return True
          elif tabuleiro[2] == tabuleiro[5] == tabuleiro[8] and (tabuleiro[2] != "3" or tabuleiro[2] != "6" or tabuleiro[2] != "9"):
              vencedor = tabuleiro[3]
              return True
#vitória ou empate - diagonal 
      def Diagonal(tabuleiro):
          global vencedor
          if tabuleiro[0] == tabuleiro[4] == tabuleiro[8] and (tabuleiro[0] != "1" or tabuleiro[0] != "5" or tabuleiro[0] != "9"):
              vencedor = tabuleiro[0]
              return True
          elif tabuleiro[2] == tabuleiro[4] == tabuleiro[6] and (tabuleiro[2] != "3" or tabuleiro[2] != "5" or tabuleiro[2] != "7"):
              vencedor = tabuleiro[2]
              return True
#Vitória
      def Vitoria(tabuleiro):
          global jogo
          if Horizontal(tabuleiro):
              Tabuleiro(tabuleiro)
              print(f"Vencedor é: {vencedor}!")
              jogo = False
          elif Vertical(tabuleiro):
              Tabuleiro(tabuleiro)
              print(f"Vencedor é: {vencedor}!")
              jogo = False

          elif Diagonal(tabuleiro):
              Tabuleiro(tabuleiro)
              print(f"Vencedor é: {vencedor}!")
              jogo = False
#Empate
      def Empate(tabuleiro):
          global jogo
          if "-" not in tabuleiro:
              Tabuleiro(tabuleiro)
              print("Empate!")
              jogo = False
#Troca de jogadores
      def Troca():
          global jogador
          if jogador == "X":
              jogador = "O"
          else:
              jogador = "X"
      def computer(tabuleiro):
          while jogador == "O":
              posicao = random.randint(0, 8)
              if tabuleiro[posicao] == "-":
                  tabuleiro[posicao] = "O"
                  Troca()
      while jogo:
          Tabuleiro(tabuleiro)
          Pjogador(tabuleiro)
          Vitoria(tabuleiro)
          Empate(tabuleiro)
          Troca()
          computer(tabuleiro)
          Vitoria(tabuleiro)
          Empate(tabuleiro)
  else:
    exit()
def menu(opcoes=None):
  opcoes = input("Insira o número da opção que deseja:\n1.Registar\n2.Acesso\n3.Sair\n")
  if opcoes == "1":
    registar()
  else:
    if opcoes == "2":
      acesso()
    else:
      if opcoes == "3":
        exit()
      else:
        print("Por favor introduza uma opcao")
        menu()
menu()