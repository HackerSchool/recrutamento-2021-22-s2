#ifndef __LOGIN_H__
#define __LOGIN_H__

#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>

int starting_screan_printer();
int resetter();
int regist();
int login();
int manager();

#endif