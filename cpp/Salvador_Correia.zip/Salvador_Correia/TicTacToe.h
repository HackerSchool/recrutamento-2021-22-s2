#ifndef __TICTACTOE_H__
#define __TICTACTOE_H__

#include <iostream>
#include <stdlib.h>
#include <cstdlib>

using namespace std;

void drawBoard(char board[9]);
bool Won(char board[9]);
int game();



#endif