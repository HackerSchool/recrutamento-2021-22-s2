#ifndef __CHATBOT_H__
#define __CHATBOT_H__

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int chatbot();

#endif