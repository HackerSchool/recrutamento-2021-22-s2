#ifndef __CALCULATOR_H__
#define __CALCULATOR_H__

#include <iostream>
#include <stdlib.h>


using namespace std;

int option_screan_printer();
int simple_operation();
int calculator();

#endif